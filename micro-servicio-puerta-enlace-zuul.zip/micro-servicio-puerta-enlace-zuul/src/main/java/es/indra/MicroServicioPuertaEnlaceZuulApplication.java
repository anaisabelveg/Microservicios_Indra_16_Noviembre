package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioPuertaEnlaceZuulApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPuertaEnlaceZuulApplication.class, args);
	}

}
