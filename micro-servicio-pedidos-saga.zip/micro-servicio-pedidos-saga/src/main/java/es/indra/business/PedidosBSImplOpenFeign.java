package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.clients.ProveedoresClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary  // Damos prioridad en la DI
public class PedidosBSImplOpenFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign productosClienteFeign;
	
	@Autowired
	private ProveedoresClienteFeign proveedoresClienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = productosClienteFeign.buscar(id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retornar el pedido
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		Producto producto = null;
		String mensaje = "";
		
		try {
			// Dar de alta el producto
			producto = productosClienteFeign.nuevo(descripcion, precio);
			
			// Dar de alta el proveedor
			mensaje = proveedoresClienteFeign.altaProveedor(nombreProveedor);
			
		} catch (Exception e) {
			// Deshacemos la transaccion, eliminar el producto
			mensaje = productosClienteFeign.eliminar(producto.getID());
			System.out.println(mensaje + "**************************");
			
			mensaje = "Transaccion deshecha";
		}
		
		return mensaje;
	}

}








