package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {

	// Igual que con try-catch podemos tener multiples catch
	// Aqui, podemos tener varios metodos que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/2654/cantidad/250
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorValidacion(FeignException ex){
		return new ResponseEntity<String>("ID del producto esta fuera de rango 1-6", HttpStatus.NOT_FOUND);
	}
	
	// http://localhost:8002/crear/tyryrtert/cantidad/250
	@ExceptionHandler(NumberFormatException.class)
	public ResponseEntity<String> errorIdTexto(NumberFormatException ex){
		return new ResponseEntity<String>("ID del producto debe ser numerico", HttpStatus.BAD_REQUEST);
	}
	
	// http://localhost:8002/crear/2654/cantidad/250
//	@ExceptionHandler(RuntimeException.class)
//	public ResponseEntity<String> errorNoExisteId(RuntimeException ex){
//		return new ResponseEntity<String>("ID del producto no existe", HttpStatus.NOT_FOUND);
//	}
}
