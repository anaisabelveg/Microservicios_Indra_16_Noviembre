package es.indra.business;

public class ProveedoresBSImpl implements IProveedoresBS{

	@Override
	public String crearProveedor(String nombre) {
		
		if ("Pepe".equals(nombre)) {
			throw new RuntimeException("Transaccion cancelada por nombre Pepe");
		} else {
			return "Proveedor " + nombre + " creado correctamente";
		}
	}

}
