package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import es.indra.entities.Producto;

// En Spring Boot cuando detecta que heredamos de cualquier xxxRepository, lo detecta como un bean
public interface ProductosDAO extends JpaRepository<Producto, Long>{

	// Podemos crear metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	public List<Producto> findByDescripcion(String descripcion);
	
	public List<Producto> findByPrecioBetween(double min, double max);
	
	public List<Producto> findByPrecioBetweenOrderByDescripcion(double min, double max);
	
	public List<Producto> findByPrecioBetweenOrderByDescripcionDesc(double min, double max);
	
	@Query("select p from Producto p where p.precio < ?1")
	public List<Producto> miQuery(double precio);
	
}
