package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductosBSImpl implements IProductosBS {
	
	//@Autowired
	private ProductosDAO dao;
	
	// En versiones recientes de Spring se recomienda inyectar los beans a través del constructor
	public ProductosBSImpl(ProductosDAO dao) {
		super();
		this.dao = dao;
	}

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
